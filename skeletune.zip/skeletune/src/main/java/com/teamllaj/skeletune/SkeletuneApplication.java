package com.teamllaj.skeletune;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkeletuneApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkeletuneApplication.class, args);
	}

}
