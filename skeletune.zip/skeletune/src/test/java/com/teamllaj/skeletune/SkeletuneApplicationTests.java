package com.teamllaj.skeletune;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkeletuneApplicationTests {

	@Test
	void contextLoads() {
	}

}
